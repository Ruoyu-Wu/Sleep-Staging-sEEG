import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from sklearn.metrics import f1_score, accuracy_score
from model_DeepSleepSEEG import DeepSleepSEEG  # Assuming this is your model class

# Paths to the dataset and output directory
train_data_path = '/root/autodl-tmp/train_data_noCoordinates.npz'
test_data_path = '/root/autodl-tmp/test_data_noCoordinates.npz'
output_dir = '/root/autodl-tmp/'

# Load the datasets
train_data = np.load(train_data_path)
test_data = np.load(test_data_path)

X_train = train_data['X']
y_train = train_data['y']
X_test = test_data['X']
y_test = test_data['y']
X_train = X_train[:, 0:3000]
X_test = X_test[:, 0:3000]
X_train = X_train.reshape(4576, 1, 3000)
X_test = X_test.reshape(1144, 1, 3000)

# Check data shapes
print("Data shapes:")
print(f"X_train: {X_train.shape}")
print(f"y_train: {y_train.shape}")
print("Label distribution:", np.unique(y_train, return_counts=True))

# Initialize the model
model = DeepSleepSEEG()

# Move model to GPU if available
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model.to(device)

# Set up optimizer and loss function
optimizer = optim.Adam(model.parameters())
criterion = nn.CrossEntropyLoss()

# Initialize lists to store metrics
train_loss_history = []
val_loss_history = []
val_f1_history = []
val_accuracy_history = []

# Training loop
num_epochs = 400
for epoch in range(num_epochs):
    model.train()
    optimizer.zero_grad()
    outputs = model(torch.tensor(X_train, dtype=torch.float).to(device))
    train_loss = criterion(outputs, torch.tensor(y_train).to(device))
    train_loss.backward()
    optimizer.step()
    
    # Append training loss
    train_loss_history.append(train_loss.item())

    # Validation step
    model.eval()
    with torch.no_grad():
        outputs = model(torch.tensor(X_test, dtype=torch.float).to(device))
        val_loss = criterion(outputs, torch.tensor(y_test).to(device))
        _, predicted = torch.max(outputs, 1)
        f1 = f1_score(y_test, predicted.cpu(), average='weighted')
        accuracy = accuracy_score(y_test, predicted.cpu())
        
        # Append validation metrics
        val_loss_history.append(val_loss.item())
        val_f1_history.append(f1)
        val_accuracy_history.append(accuracy)

    # Print progress every 10 epochs
    if epoch % 10 == 0:
        print(f"Epoch {epoch}:")
        print(f"Training Loss: {train_loss.item():.4f}")
        print(f"Validation Loss: {val_loss.item():.4f}")
        print(f"Validation F1 Score: {f1:.2f}")
        print(f"Validation Accuracy: {accuracy:.2f}")

    if torch.cuda.is_available():
        torch.cuda.empty_cache()

# Save the loss and metrics history to CSV files
pd.DataFrame({'Epoch': range(num_epochs), 'Train_Loss': train_loss_history, 'Validation_Loss': val_loss_history}).to_csv(f"{output_dir}/loss_history.csv", index=False)
pd.DataFrame({'Epoch': range(num_epochs), 'Validation_F1': val_f1_history}).to_csv(f"{output_dir}/f1_history.csv", index=False)
pd.DataFrame({'Epoch': range(num_epochs), 'Validation_Accuracy': val_accuracy_history}).to_csv(f"{output_dir}/accuracy_history.csv", index=False)

# Final evaluation on test data
model.eval()
with torch.no_grad():
    outputs = model(torch.tensor(X_test, dtype=torch.float).to(device))
    _, predicted = torch.max(outputs, 1)
    f1 = f1_score(y_test, predicted.cpu(), average='weighted')
    accuracy = accuracy_score(y_test, predicted.cpu())

print(f'Final Test F1 Score: {f1:.2f}')
print(f'Final Test Accuracy: {accuracy:.2f}')

# Save the trained model
torch.save(model.state_dict(), f'{output_dir}/trained_model_400epo.pth')